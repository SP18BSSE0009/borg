package net.sf.borg.common;

public interface Observable {

}
