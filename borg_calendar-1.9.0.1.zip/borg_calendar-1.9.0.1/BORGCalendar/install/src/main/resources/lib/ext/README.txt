JARs placed into this folder will by dynamically loaded into the program if the dynamic loading 
option is enabled. It is disabled by default.
Dynamic loading is primarily used for:
- adding additional database drivers
- adding additional Java Look and Feels
- adding Borg plugins