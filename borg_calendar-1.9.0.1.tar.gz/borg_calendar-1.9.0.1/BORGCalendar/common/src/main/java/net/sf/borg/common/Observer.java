package net.sf.borg.common;

public interface Observer {

	void update(Observable o, Object arg);

}
